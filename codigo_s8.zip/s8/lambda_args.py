print (lambda x: x + 1)             # devuelve la info de la función anónima

print ((lambda x: x + 1) (5))       # pasamos un argumento a la función anónima

print ((lambda x, y: x + y)(1,2))   # pasamos dos argumentos a la función anónima