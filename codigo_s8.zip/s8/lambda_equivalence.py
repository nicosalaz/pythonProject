sumar_one = lambda x: x + 1

print(sumar_one(2))

def add_one(x):
    return x + 1

print (sumar_one(2))