class manipularArchivos:
    def escribirArchivo(self,datos,ubicacion):

    def leerArchivo(self,ubicacion):
