from TAP.TPA.Control import Control


control = Control()
control.menu()

