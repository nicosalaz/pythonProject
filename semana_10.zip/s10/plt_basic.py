import numpy as np
import matplotlib.pyplot as plt

plt.plot([0, 0.1, 0.2, 0.5,0.6], [1, -1, 0, 3, -1])
plt.show()