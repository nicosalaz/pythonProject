import numpy as np

# creamos el arreglo de 6x6 con step de 1 en las columnas y
# step de 10 en las filas
filas = np.arange(6)
print(filas)
columnas = np.arange(0, 51, 10) #[:, np.newaxis]
print(columnas)

a = filas + columnas
print(a)
# lo anterior es equivalente a:
#   a = np.arange(6) + np.arange(0, 51, 10)[:, np.newaxis]

# accediendo a los elementos de la matriz
print (a[0, 3:5])
print (a[4:, 4:])
print (a[:, 2])